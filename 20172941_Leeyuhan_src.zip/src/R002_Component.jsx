import React, { Component } from 'react';

class R002_ImportComponent extends Component {
  render() {
    return (
      <div>
        <h2 className='r002-title'>첫번째 실습</h2>
        <p className='r002-script'>
          이 모양을 만든 후 src폴더만 압축하여 사이버캠퍼스 과제게시판에 올려 주세요
        </p>
        <p className='r002-script'>
          다른 사람의 것을 보고 하면 안됩니다.
        </p>
      </div>
    );
  }
}

export default R002_ImportComponent;